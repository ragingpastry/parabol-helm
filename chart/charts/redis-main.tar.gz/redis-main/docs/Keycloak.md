# Single Sign On

Redis cannot currently be deployed with Single Sign on.